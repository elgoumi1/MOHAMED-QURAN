import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Google GenAI client if GEMINI_API_KEY is available
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Quran AI Assistant Endpoint
app.post('/api/gemini/chat', async (req: Request, res: Response) => {
  const { message, language = 'ar', context } = req.body;

  if (!message || typeof message !== 'string') {
    res.status(400).json({ error: 'Message is required' });
    return;
  }

  // Graceful fallback if API key is not configured
  if (!ai) {
    const fallbackAnswers: Record<string, string> = {
      ar: 'أهلاً بك في المساعد القرآني الذكي. يرجى تهيئة مفتاح GEMINI_API_KEY للاستفادة الكاملة من التحليل الذكي المتقدم. يمكنك الاستمرار في تصفح المصحف، الاستماع لتلاوات القراء، وقراءة التفسير الموثق مباشرة من المنصة.',
      en: 'Welcome to the Quran AI Assistant. Please configure GEMINI_API_KEY for advanced intelligent analysis. You can continue listening to recitations, reading the digital Quran, and exploring verified Tafsir directly.',
      fr: "Bienvenue dans l'Assistant Coranique IA. Veuillez configurer GEMINI_API_KEY pour l'analyse avancée. Vous pouvez continuer à écouter les récitations et lire le Coran vérifié.",
    };
    res.json({ reply: fallbackAnswers[language] || fallbackAnswers.ar });
    return;
  }

  try {
    const systemPrompt = `You are the Quran Reciters PRO AI Assistant, a reverent, authentic, and scholarly Islamic digital guide.
Your purpose is to explain Quranic verses, vocabulary, Tajweed principles, context of revelation (Asbab al-Nuzul), and verified Tafsir (e.g., Ibn Kathir, Al-Saadi).
Rules:
1. Always maintain maximum reverence and respect for the Holy Quran and Islamic traditions.
2. Never invent, alter, or hallucinate Quranic verses. Quote authentic Arabic text when citing verses, accompanied by their Surah name and Verse number (e.g., [سورة الشرح: 6]).
3. Respond in the requested language: ${language === 'fr' ? 'French' : language === 'en' ? 'English' : 'Arabic'}.
4. Do not deliver fatwas or personal legal decrees. State verified scholastic viewpoints and advise consulting certified scholars for specific rulings.
5. Provide clear, structured, beautiful Markdown formatting with headings and bullet points.
${context ? `Current user context: ${JSON.stringify(context)}` : ''}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    res.json({ reply: response.text || '' });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    res.status(500).json({
      error: 'Failed to process AI request',
      details: error.message || 'Unknown error',
    });
  }
});

// Semantic & Topic Quran Search
app.post('/api/gemini/search', async (req: Request, res: Response) => {
  const { query, language = 'ar' } = req.body;

  if (!query) {
    res.status(400).json({ error: 'Search query is required' });
    return;
  }

  if (!ai) {
    res.json({
      summary: language === 'ar' ? `نتائج البحث الذكي عن: "${query}"` : `Smart search results for: "${query}"`,
      relevantVerses: [
        {
          surahNumber: 94,
          surahName: 'الشرح',
          verseNumber: 6,
          arabicText: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
          translation: 'Indeed, with hardship comes ease.',
          theme: 'الصبر والفرج وتيسير الأمور',
        },
        {
          surahNumber: 2,
          surahName: 'البقرة',
          verseNumber: 153,
          arabicText: 'يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',
          translation: 'O you who have believed, seek help through patience and prayer. Indeed, Allah is with the patient.',
          theme: 'الاستعانة بالصبر والصلاة',
        },
      ],
    });
    return;
  }

  try {
    const prompt = `Perform a semantic search in the Holy Quran for the query: "${query}".
Identify the most relevant verses, themes, and reflection points. Return response strictly in valid JSON format matching this schema:
{
  "summary": "Brief explanation of how the Quran addresses this concept in ${language}",
  "relevantVerses": [
    {
      "surahNumber": 1,
      "surahName": "Surah name in Arabic",
      "verseNumber": 1,
      "arabicText": "Authentic Arabic text with tashkeel",
      "translation": "Translation in ${language}",
      "theme": "Key takeaway or lesson"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (err: any) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Personalized Memorization Plan Generator
app.post('/api/gemini/memorize-plan', async (req: Request, res: Response) => {
  const { targetSurah, currentLevel, dailyMinutes, days, language = 'ar' } = req.body;

  if (!ai) {
    res.json({
      title: language === 'ar' ? `خطة حفظ مخصصة: ${targetSurah || 'سورة الملك'}` : `Memorization Plan: ${targetSurah || 'Surah Al-Mulk'}`,
      dailyTarget: language === 'ar' ? '5 آيات يومياً مع المراجعة التراكمية' : '5 verses daily with cumulative revision',
      schedule: [
        { day: 1, verses: '1-5', task: 'حفظ جديد وتكرار 10 مرات', revision: 'قراءة بالتجويد' },
        { day: 2, verses: '6-10', task: 'حفظ جديد وتكرار 10 مرات', revision: 'تسميع الآيات 1-5' },
        { day: 3, verses: '11-15', task: 'حفظ جديد وتكرار 10 مرات', revision: 'ربط الآيات 1-10' },
        { day: 4, verses: '1-15', task: 'مراجعة تثبيت كاملة', revision: 'تسميع غيباً' },
      ],
      tajweedTips: ['الانتباه للمدود في أواخر الآيات', 'مراعاة أحكام النون الساكنة والتنوين (الإخفاء والإدغام)'],
    });
    return;
  }

  try {
    const prompt = `Generate a personalized Quran memorization and revision schedule.
Target Surah: ${targetSurah || 'Al-Mulk'}
Current Level: ${currentLevel || 'Beginner'}
Available daily time: ${dailyMinutes || 20} minutes
Timeline: ${days || 7} days
Language: ${language}

Return strictly a valid JSON object with:
{
  "title": "Plan title",
  "dailyTarget": "Daily goal summary",
  "schedule": [
    { "day": 1, "verses": "1-5", "task": "Memorization task description", "revision": "Revision task" }
  ],
  "tajweedTips": ["Tip 1", "Tip 2"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' },
    });

    res.json(JSON.parse(response.text || '{}'));
  } catch (err: any) {
    console.error('Memorization plan error:', err);
    res.status(500).json({ error: 'Failed to generate plan' });
  }
});

// Interactive Educational Quiz Generator
app.post('/api/gemini/quiz', async (req: Request, res: Response) => {
  const { topic = 'tajweed', difficulty = 'medium', language = 'ar' } = req.body;

  if (!ai) {
    res.json({
      questions: [
        {
          id: 1,
          question: language === 'ar' ? 'ما هو حكم النون الساكنة في قوله تعالى: (مِنْ بَعْدِ)؟' : 'What is the Tajweed rule in (مِنْ بَعْدِ)?',
          options: language === 'ar' ? ['إظهار حلقي', 'إقلاب', 'إدغام بغنة', 'إخفاء حقيقي'] : ['Izhar', 'Iqlab', 'Idgham with Ghunnah', 'Ikhfa'],
          correctIndex: 1,
          explanation: language === 'ar' ? 'تقلب النون الساكنة ميماً مخفاة بغنة إذا جاء بعدها حرف الباء.' : 'The Noon Sakinah turns into Meem with Ghunnah before Baa.',
        },
        {
          id: 2,
          question: language === 'ar' ? 'كم عدد حروف الإظهار الحلقي؟' : 'How many are the throat Izhar letters?',
          options: ['4 حروف', '6 حروف (ء، هـ، ع، ح، غ، خ)', '8 حروف', '15 حرفاً'],
          correctIndex: 1,
          explanation: language === 'ar' ? 'حروف الإظهار ستة مجموعة في أوائل كلمات: أخي هاك علماً حازه غير خاسر.' : 'Six letters: Hamzah, Ha, Ain, Haa, Ghain, Kha.',
        },
      ],
    });
    return;
  }

  try {
    const prompt = `Create a 3-question Islamic educational quiz on topic: ${topic}, difficulty: ${difficulty}, in language: ${language}.
Return JSON only:
{
  "questions": [
    {
      "id": 1,
      "question": "Question text",
      "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
      "correctIndex": 0,
      "explanation": "Detailed pedagogical explanation"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' },
    });

    res.json(JSON.parse(response.text || '{}'));
  } catch (err: any) {
    console.error('Quiz error:', err);
    res.status(500).json({ error: 'Quiz generation failed' });
  }
});

// Start dev or production server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Quran Reciters PRO server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup error:', err);
});
